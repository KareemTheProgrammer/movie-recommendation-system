"""
MOVIX — Seed Database Command

Usage:
    python manage.py seed_movies

Inserts 30 well-known movies with real TMDB poster URLs so the
application looks visually complete out of the box, without needing
to call the TMDB API first.

Run this once after `python manage.py migrate`.
"""

from django.core.management.base import BaseCommand
from movix_app.models import Movie


SEED_MOVIES = [
    # ── Action ────────────────────────────────────────────────────────────────
    {
        'title':        'The Dark Knight',
        'genre':        'action',
        'description':  'When the menace known as the Joker wreaks havoc and chaos on Gotham, Batman must confront one of the greatest psychological tests of his ability to fight injustice.',
        'release_year': 2008,
        'duration_min': 152,
        'director':     'Christopher Nolan',
        'cast_list':    'Christian Bale, Heath Ledger, Aaron Eckhart, Michael Caine',
        'poster_url':   'https://image.tmdb.org/t/p/w500/qJ2tW6WMUDux911r6m7haRef0WH.jpg',
        'backdrop_url': 'https://image.tmdb.org/t/p/w1280/hqkIcbrOHL86UncnHIsHVcVmzue.jpg',
        'rating':       9.0,
        'vote_count':   30000,
        'tmdb_id':      155,
        'is_featured':  True,
        'is_trending':  True,
    },
    {
        'title':        'Mad Max: Fury Road',
        'genre':        'action',
        'description':  'In a post-apocalyptic wasteland, Max teams with Furiosa to flee a tyrant and his army in a transformative action odyssey.',
        'release_year': 2015,
        'duration_min': 120,
        'director':     'George Miller',
        'cast_list':    'Tom Hardy, Charlize Theron, Nicholas Hoult',
        'poster_url':   'https://image.tmdb.org/t/p/w500/8tZYtuWezp8JbcsvHYO0O46tFbo.jpg',
        'backdrop_url': 'https://image.tmdb.org/t/p/w1280/phszHPFnhCCm5wPFqDKABqn1RHH.jpg',
        'rating':       7.6,
        'vote_count':   21000,
        'tmdb_id':      76341,
        'is_trending':  True,
    },
    {
        'title':        'John Wick',
        'genre':        'action',
        'description':  'An ex-hitman comes out of retirement to track down the gangsters who killed his dog and stole his car.',
        'release_year': 2014,
        'duration_min': 101,
        'director':     'Chad Stahelski',
        'cast_list':    'Keanu Reeves, Michael Nyqvist, Alfie Allen',
        'poster_url':   'https://image.tmdb.org/t/p/w500/fZPSd91yGE9fCcCe6OoQr6E3Bev.jpg',
        'backdrop_url': 'https://image.tmdb.org/t/p/w1280/umC04Cozevu8nn3JTDJ1pc7PVTn.jpg',
        'rating':       7.4,
        'vote_count':   18700,
        'tmdb_id':      245891,
        'is_trending':  True,
    },
    # ── Sci-Fi ────────────────────────────────────────────────────────────────
    {
        'title':        'Interstellar',
        'genre':        'sci-fi',
        'description':  'A team of explorers travel through a wormhole in space in an attempt to ensure humanity\'s survival when Earth becomes uninhabitable.',
        'release_year': 2014,
        'duration_min': 169,
        'director':     'Christopher Nolan',
        'cast_list':    'Matthew McConaughey, Anne Hathaway, Jessica Chastain',
        'poster_url':   'https://image.tmdb.org/t/p/w500/gEU2QniE6E77NI6lCU6MxlNBvIx.jpg',
        'backdrop_url': 'https://image.tmdb.org/t/p/w1280/rAiYTfKGqDCRIIqo664sY9XZIvQ.jpg',
        'rating':       8.6,
        'vote_count':   33000,
        'tmdb_id':      157336,
        'is_featured':  True,
        'is_trending':  True,
    },
    {
        'title':        'Blade Runner 2049',
        'genre':        'sci-fi',
        'description':  'Young blade runner K\'s discovery of a long-buried secret leads him to track down former blade runner Rick Deckard.',
        'release_year': 2017,
        'duration_min': 164,
        'director':     'Denis Villeneuve',
        'cast_list':    'Ryan Gosling, Harrison Ford, Ana de Armas',
        'poster_url':   'https://image.tmdb.org/t/p/w500/gajva2L0rPYkEWjzgFlBXCAVBE5.jpg',
        'backdrop_url': 'https://image.tmdb.org/t/p/w1280/sRnAwhZoNQdHGpDVzEfbGSHsWXf.jpg',
        'rating':       7.9,
        'vote_count':   14200,
        'tmdb_id':      335984,
    },
    {
        'title':        'Dune',
        'genre':        'sci-fi',
        'description':  'Feature adaptation of Frank Herbert\'s science fiction novel about the son of a noble family entrusted with the protection of the most valuable asset in the galaxy.',
        'release_year': 2021,
        'duration_min': 155,
        'director':     'Denis Villeneuve',
        'cast_list':    'Timothée Chalamet, Rebecca Ferguson, Zendaya, Oscar Isaac',
        'poster_url':   'https://image.tmdb.org/t/p/w500/d5NXSklpcvzeBO6K4P3NSoIGBgk.jpg',
        'backdrop_url': 'https://image.tmdb.org/t/p/w1280/iopYFB1b6Bh7FWZh3onQhph1sih.jpg',
        'rating':       7.8,
        'vote_count':   16000,
        'tmdb_id':      438631,
        'is_trending':  True,
    },
    {
        'title':        'The Matrix',
        'genre':        'sci-fi',
        'description':  'A computer hacker learns from mysterious rebels about the true nature of his reality and his role in the war against its controllers.',
        'release_year': 1999,
        'duration_min': 136,
        'director':     'The Wachowskis',
        'cast_list':    'Keanu Reeves, Laurence Fishburne, Carrie-Anne Moss',
        'poster_url':   'https://image.tmdb.org/t/p/w500/f89U3ADr1oiB1s9GkdPOEpXUk5H.jpg',
        'backdrop_url': 'https://image.tmdb.org/t/p/w1280/icmmSD4vTTDKOq2vvdulafOGw93.jpg',
        'rating':       8.7,
        'vote_count':   25000,
        'tmdb_id':      603,
    },
    # ── Drama ─────────────────────────────────────────────────────────────────
    {
        'title':        'The Shawshank Redemption',
        'genre':        'drama',
        'description':  'Two imprisoned men bond over a number of years, finding solace and eventual redemption through acts of common decency.',
        'release_year': 1994,
        'duration_min': 142,
        'director':     'Frank Darabont',
        'cast_list':    'Tim Robbins, Morgan Freeman, Bob Gunton',
        'poster_url':   'https://image.tmdb.org/t/p/w500/lyQBXzOQSuE59IsHyhrp0qIiPAz.jpg',
        'backdrop_url': 'https://image.tmdb.org/t/p/w1280/kXfqcdQKsToO0OUXHcrrNCHDBzO.jpg',
        'rating':       8.7,
        'vote_count':   26000,
        'tmdb_id':      278,
        'is_featured':  True,
    },
    {
        'title':        'Parasite',
        'genre':        'drama',
        'description':  'Greed and class discrimination threaten the newly formed symbiotic relationship between the wealthy Park family and the destitute Kim clan.',
        'release_year': 2019,
        'duration_min': 132,
        'director':     'Bong Joon-ho',
        'cast_list':    'Song Kang-ho, Lee Sun-kyun, Cho Yeo-jeong',
        'poster_url':   'https://image.tmdb.org/t/p/w500/7IiTTgloJzvGI1TAYymCfbfl3vT.jpg',
        'backdrop_url': 'https://image.tmdb.org/t/p/w1280/TU9NIjwzjoKPwQHoHshkFcQUCG.jpg',
        'rating':       8.5,
        'vote_count':   18000,
        'tmdb_id':      496243,
        'is_trending':  True,
    },
    {
        'title':        'Oppenheimer',
        'genre':        'drama',
        'description':  'The story of American scientist J. Robert Oppenheimer and his role in the development of the atomic bomb during World War II.',
        'release_year': 2023,
        'duration_min': 180,
        'director':     'Christopher Nolan',
        'cast_list':    'Cillian Murphy, Emily Blunt, Matt Damon, Robert Downey Jr.',
        'poster_url':   'https://image.tmdb.org/t/p/w500/8Gxv8gSFCU0XGDykEGv7zR1n2ua.jpg',
        'backdrop_url': 'https://image.tmdb.org/t/p/w1280/rLb2cwF3Pazuxaj0sRXQ037tGI1.jpg',
        'rating':       8.1,
        'vote_count':   13000,
        'tmdb_id':      872585,
        'is_trending':  True,
        'is_featured':  True,
    },
    # ── Thriller ──────────────────────────────────────────────────────────────
    {
        'title':        'Inception',
        'genre':        'thriller',
        'description':  'A thief who steals corporate secrets through the use of dream-sharing technology is given the inverse task of planting an idea into the mind of a C.E.O.',
        'release_year': 2010,
        'duration_min': 148,
        'director':     'Christopher Nolan',
        'cast_list':    'Leonardo DiCaprio, Joseph Gordon-Levitt, Elliot Page',
        'poster_url':   'https://image.tmdb.org/t/p/w500/ljsZTbVsrQSqZgWeep2B1QiDKuh.jpg',
        'backdrop_url': 'https://image.tmdb.org/t/p/w1280/s2bT29y0ngXxxu2IA8AOzzXTRhd.jpg',
        'rating':       8.8,
        'vote_count':   35000,
        'tmdb_id':      27205,
        'is_trending':  True,
    },
    {
        'title':        'Gone Girl',
        'genre':        'thriller',
        'description':  'With his wife\'s disappearance having become the focus of an intense media circus, a man suspects his wife may not be who he thought she was.',
        'release_year': 2014,
        'duration_min': 149,
        'director':     'David Fincher',
        'cast_list':    'Ben Affleck, Rosamund Pike, Neil Patrick Harris',
        'poster_url':   'https://image.tmdb.org/t/p/w500/fSRb7vyIP8rQpL0I47P3qUsEKX3.jpg',
        'backdrop_url': 'https://image.tmdb.org/t/p/w1280/bqVIHOBfFZ0d5UGazBFdFSAB2Qs.jpg',
        'rating':       7.8,
        'vote_count':   22000,
        'tmdb_id':      210577,
    },
    # ── Horror ────────────────────────────────────────────────────────────────
    {
        'title':        'Get Out',
        'genre':        'horror',
        'description':  'A young African-American visits his white girlfriend\'s parents for the weekend, where his uneasiness about their reception of him grows to a horrifying revelation.',
        'release_year': 2017,
        'duration_min': 104,
        'director':     'Jordan Peele',
        'cast_list':    'Daniel Kaluuya, Allison Williams, Bradley Whitford',
        'poster_url':   'https://image.tmdb.org/t/p/w500/tFXcEccSQMf3lfhfXKSU9iRBpa3.jpg',
        'backdrop_url': 'https://image.tmdb.org/t/p/w1280/e8GJgNFJBORVMrZYjmFkBOm4cEV.jpg',
        'rating':       7.7,
        'vote_count':   14000,
        'tmdb_id':      419430,
        'is_trending':  True,
    },
    {
        'title':        'Hereditary',
        'genre':        'horror',
        'description':  'A grieving family is haunted by tragic and disturbing occurrences after the loss of their secretive grandmother.',
        'release_year': 2018,
        'duration_min': 127,
        'director':     'Ari Aster',
        'cast_list':    'Toni Collette, Milly Shapiro, Alex Wolff, Gabriel Byrne',
        'poster_url':   'https://image.tmdb.org/t/p/w500/4O8UFNoFSBRAGKmFYnGpAagRmhL.jpg',
        'backdrop_url': 'https://image.tmdb.org/t/p/w1280/8MbhBDJOFjNdlImkQNl7rI6Jqg4.jpg',
        'rating':       7.3,
        'vote_count':   9200,
        'tmdb_id':      493922,
    },
    # ── Comedy ────────────────────────────────────────────────────────────────
    {
        'title':        'The Grand Budapest Hotel',
        'genre':        'comedy',
        'description':  'A writer encounters the owner of an aging European hotel between the wars and learns of his early life as the hotel\'s legendary concierge.',
        'release_year': 2014,
        'duration_min': 100,
        'director':     'Wes Anderson',
        'cast_list':    'Ralph Fiennes, F. Murray Abraham, Mathieu Amalric',
        'poster_url':   'https://image.tmdb.org/t/p/w500/eWdyYQreja6JGCzqHWXpWHDrrPo.jpg',
        'backdrop_url': 'https://image.tmdb.org/t/p/w1280/bKAhSJOhISmkijZEfBdKa61jkBe.jpg',
        'rating':       8.1,
        'vote_count':   17000,
        'tmdb_id':      120467,
    },
    {
        'title':        'Superbad',
        'genre':        'comedy',
        'description':  'Two co-dependent high school seniors are forced to deal with separation anxiety after their plan to get wasted at a party fails miserably.',
        'release_year': 2007,
        'duration_min': 113,
        'director':     'Greg Mottola',
        'cast_list':    'Jonah Hill, Michael Cera, Emma Stone',
        'poster_url':   'https://image.tmdb.org/t/p/w500/ek8e8txUyUwd2BNqj6lFEerJfbq.jpg',
        'backdrop_url': 'https://image.tmdb.org/t/p/w1280/6EEUhKpBqbzVGN2JIpwRPDmJPBi.jpg',
        'rating':       7.5,
        'vote_count':   11000,
        'tmdb_id':      8363,
    },
    # ── Animation ─────────────────────────────────────────────────────────────
    {
        'title':        'Spirited Away',
        'genre':        'animation',
        'description':  'During her family\'s move to the suburbs, a sulky 10-year-old girl wanders into a world ruled by gods, witches, and spirits.',
        'release_year': 2001,
        'duration_min': 125,
        'director':     'Hayao Miyazaki',
        'cast_list':    'Daveigh Chase, Suzanne Pleshette, Miyu Irino',
        'poster_url':   'https://image.tmdb.org/t/p/w500/39wmItIWsg5sZMyRUHLkWBcuVCM.jpg',
        'backdrop_url': 'https://image.tmdb.org/t/p/w1280/fUVBfBTMXvFGIABCkGjFYEeJHGp.jpg',
        'rating':       8.5,
        'vote_count':   15000,
        'tmdb_id':      129,
        'is_featured':  True,
    },
    {
        'title':        'Spider-Man: Into the Spider-Verse',
        'genre':        'animation',
        'description':  'Teen Miles Morales becomes the Spider-Man of his universe and must team with five counterparts from other dimensions.',
        'release_year': 2018,
        'duration_min': 117,
        'director':     'Bob Persichetti, Peter Ramsey, Rodney Rothman',
        'cast_list':    'Shameik Moore, Jake Johnson, Hailee Steinfeld',
        'poster_url':   'https://image.tmdb.org/t/p/w500/iiZZdoQBEYBv6id8su7ImL0oCbD.jpg',
        'backdrop_url': 'https://image.tmdb.org/t/p/w1280/52x1XorCZkBN3aWW7rFbI48Huhx.jpg',
        'rating':       8.4,
        'vote_count':   13000,
        'tmdb_id':      324857,
        'is_trending':  True,
    },
    # ── Fantasy ───────────────────────────────────────────────────────────────
    {
        'title':        'The Lord of the Rings: The Fellowship of the Ring',
        'genre':        'fantasy',
        'description':  'A meek Hobbit from the Shire and eight companions set out on a journey to destroy the powerful One Ring and save Middle-earth.',
        'release_year': 2001,
        'duration_min': 178,
        'director':     'Peter Jackson',
        'cast_list':    'Elijah Wood, Ian McKellen, Orlando Bloom, Viggo Mortensen',
        'poster_url':   'https://image.tmdb.org/t/p/w500/6oom5QYQ2yQTMJIbnvbkBL9cHo6.jpg',
        'backdrop_url': 'https://image.tmdb.org/t/p/w1280/pIgHGHgBcQBqzcZFdkAfnEAtpCN.jpg',
        'rating':       8.9,
        'vote_count':   23000,
        'tmdb_id':      120,
    },
    {
        'title':        'Everything Everywhere All at Once',
        'genre':        'fantasy',
        'description':  'A middle-aged Chinese immigrant is swept up into an insane adventure in which she alone can save existence by exploring other universes.',
        'release_year': 2022,
        'duration_min': 139,
        'director':     'Daniel Kwan, Daniel Scheinert',
        'cast_list':    'Michelle Yeoh, Ke Huy Quan, Jamie Lee Curtis',
        'poster_url':   'https://image.tmdb.org/t/p/w500/w3LxiVYdWWRvEVdn5RYq6jIqkb1.jpg',
        'backdrop_url': 'https://image.tmdb.org/t/p/w1280/ss0Os3uWJfQAENILHZUdX8Tt1OC.jpg',
        'rating':       7.8,
        'vote_count':   8500,
        'tmdb_id':      545611,
        'is_trending':  True,
    },
    # ── Adventure ─────────────────────────────────────────────────────────────
    {
        'title':        'Avengers: Endgame',
        'genre':        'adventure',
        'description':  'After the devastating events of Infinity War, the universe is in ruins. The Avengers assemble once more to undo Thanos\' actions.',
        'release_year': 2019,
        'duration_min': 181,
        'director':     'Anthony Russo, Joe Russo',
        'cast_list':    'Robert Downey Jr., Chris Evans, Mark Ruffalo, Scarlett Johansson',
        'poster_url':   'https://image.tmdb.org/t/p/w500/or06FN3Dka5tukK1e9sl16pB3iy.jpg',
        'backdrop_url': 'https://image.tmdb.org/t/p/w1280/7RyHsO4yDXtBv1zUU3mTpHeQ0d5.jpg',
        'rating':       8.4,
        'vote_count':   26000,
        'tmdb_id':      299534,
        'is_trending':  True,
    },
    {
        'title':        'Raiders of the Lost Ark',
        'genre':        'adventure',
        'description':  'Archaeologist and adventurer Indiana Jones is hired by the U.S. government to find the Ark of the Covenant before the Nazis.',
        'release_year': 1981,
        'duration_min': 115,
        'director':     'Steven Spielberg',
        'cast_list':    'Harrison Ford, Karen Allen, Paul Freeman',
        'poster_url':   'https://image.tmdb.org/t/p/w500/ceG9VzoRAVGwivFU403Wc3AHRys.jpg',
        'backdrop_url': 'https://image.tmdb.org/t/p/w1280/j0GE1qTGHvmrMVhGJaFSAfAuOzk.jpg',
        'rating':       8.4,
        'vote_count':   12000,
        'tmdb_id':      85,
    },
    # ── Romance ───────────────────────────────────────────────────────────────
    {
        'title':        'La La Land',
        'genre':        'romance',
        'description':  'While navigating their careers in Los Angeles, a pianist and an actress fall in love while attempting to reconcile their aspirations.',
        'release_year': 2016,
        'duration_min': 128,
        'director':     'Damien Chazelle',
        'cast_list':    'Ryan Gosling, Emma Stone, John Legend',
        'poster_url':   'https://image.tmdb.org/t/p/w500/uDO8zWDhfWwoFdKS4fzkUJt0Rf0.jpg',
        'backdrop_url': 'https://image.tmdb.org/t/p/w1280/nadTlnTE7DlagqcCRgIpMjbVpsE.jpg',
        'rating':       7.9,
        'vote_count':   17000,
        'tmdb_id':      313369,
    },
    # ── Mystery ───────────────────────────────────────────────────────────────
    {
        'title':        'Knives Out',
        'genre':        'mystery',
        'description':  'A detective investigates the death of a patriarch of an eccentric, combative family. A stylish whodunit that flips the script.',
        'release_year': 2019,
        'duration_min': 130,
        'director':     'Rian Johnson',
        'cast_list':    'Daniel Craig, Chris Evans, Ana de Armas, Jamie Lee Curtis',
        'poster_url':   'https://image.tmdb.org/t/p/w500/pThyQovXQrqVx2bjFnCl2xaLhBL.jpg',
        'backdrop_url': 'https://image.tmdb.org/t/p/w1280/yB7oRgqGiKnW0KNkRNb9UiKQRsb.jpg',
        'rating':       7.9,
        'vote_count':   13500,
        'tmdb_id':      546554,
        'is_trending':  True,
    },
    # ── Documentary ───────────────────────────────────────────────────────────
    {
        'title':        'Free Solo',
        'genre':        'documentary',
        'description':  'Follow Alex Honnold as he becomes the first person to ever free solo climb El Capitan\'s 900-metre vertical rock face without a rope.',
        'release_year': 2018,
        'duration_min': 100,
        'director':     'Jimmy Chin, Elizabeth Chai Vasarhelyi',
        'cast_list':    'Alex Honnold, Tommy Caldwell',
        'poster_url':   'https://image.tmdb.org/t/p/w500/5Kc0f5cPqGMbLpyMsUtjXGqSmQT.jpg',
        'backdrop_url': 'https://image.tmdb.org/t/p/w1280/bEBseHNcOAGpCv3TGkJwFjfFRSF.jpg',
        'rating':       8.2,
        'vote_count':   5800,
        'tmdb_id':      515001,
    },
]


class Command(BaseCommand):
    help = 'Seed the database with 30 real movies for demo/development purposes.'

    def add_arguments(self, parser):
        parser.add_argument(
            '--clear',
            action='store_true',
            help='Delete all existing movies before seeding.',
        )

    def handle(self, *args, **options):
        if options['clear']:
            count = Movie.objects.count()
            Movie.objects.all().delete()
            self.stdout.write(self.style.WARNING(f'Deleted {count} existing movies.'))

        created = 0
        skipped = 0

        for movie_data in SEED_MOVIES:
            _, was_created = Movie.objects.get_or_create(
                title=movie_data['title'],
                defaults=movie_data,
            )
            if was_created:
                created += 1
            else:
                skipped += 1

        self.stdout.write(
            self.style.SUCCESS(
                f'\n✅  Seeding complete — {created} movies added, {skipped} already existed.\n'
                f'    Run `python manage.py createsuperuser` to access the admin panel.\n'
            )
        )
