/**
 * MOVIX — Frontend Application Logic
 *
 * Architecture:
 *   - MOVIX namespace object holds all state + methods
 *   - No frameworks — clean vanilla ES6+
 *   - Communicates with Django backend via fetch() + JSON
 *
 * Modules:
 *   1. State          — central data store
 *   2. API            — all fetch calls
 *   3. UI.Hero        — hero section
 *   4. UI.Cards       — movie card factory
 *   5. UI.Grids       — render grids + pagination
 *   6. UI.Modal       — movie detail modal
 *   7. UI.Watchlist   — watchlist modal
 *   8. UI.Auth        — login/register modal
 *   9. UI.AddMovie    — add movie modal + TMDB search
 *  10. Toast          — notification system
 *  11. Events         — all event listeners
 *  12. Init           — bootstrap
 */

const MOVIX = (() => {

  // ═══════════════════════════════════════════════════════════════════════════
  // 1. STATE
  // ═══════════════════════════════════════════════════════════════════════════

  const state = {
    user:            null,       // { username, watchlist_count } | null
    currentGenre:    '',
    currentSearch:   '',
    currentPage:     1,
    totalPages:      1,
    featuredMovie:   null,
    openModalId:     null,       // id of movie currently open in detail modal
    searchDebounce:  null,
  };


  // ═══════════════════════════════════════════════════════════════════════════
  // 2. API MODULE
  // ═══════════════════════════════════════════════════════════════════════════

  const API = {
    /**
     * Base fetch wrapper — handles JSON + CSRF.
     */
    async request(url, options = {}) {
      const csrfToken = getCookie('csrftoken');
      const headers   = {
        'Content-Type': 'application/json',
        'X-CSRFToken':  csrfToken,
        ...options.headers,
      };
      try {
        const response = await fetch(url, { ...options, headers });
        const data     = await response.json();
        return { ok: response.ok, status: response.status, data };
      } catch (err) {
        return { ok: false, status: 0, data: { error: 'Network error.' } };
      }
    },

    get(url)  { return API.request(url, { method: 'GET' }); },

    post(url, body) {
      return API.request(url, {
        method: 'POST',
        body:   JSON.stringify(body),
      });
    },

    // ── Endpoints ─────────────────────────────────────────────────────────
    authStatus()       { return API.get('/api/auth/status/'); },
    login(u, p)        { return API.post('/login/', { username: u, password: p }); },
    register(u, e, p)  { return API.post('/register/', { username: u, email: e, password: p }); },

    movies(params = {}) {
      const qs = new URLSearchParams(params).toString();
      return API.get(`/api/movies/?${qs}`);
    },
    movieDetail(id)    { return API.get(`/api/movies/${id}/`); },
    addMovie(data)     { return API.post('/api/movies/add/', data); },
    deleteMovie(id)    { return API.post(`/api/movies/delete/${id}/`, {}); },

    recommend()        { return API.get('/api/recommend/'); },
    trending()         { return API.get('/api/movies/?filter=trending'); },
    watchlist()        { return API.get('/api/watchlist/'); },
    toggleWatchlist(id){ return API.post('/api/watchlist/toggle/', { movie_id: id }); },
    markWatched(id)    { return API.post('/api/watchlist/watched/', { movie_id: id }); },
    rateMovie(id, sc)  { return API.post('/api/rate/', { movie_id: id, score: sc }); },

    aiSuggest(id)      { return API.post('/api/ai/suggest/', { movie_id: id }); },
    tmdbSearch(q)      { return API.get(`/api/tmdb/search/?q=${encodeURIComponent(q)}`); },
    tmdbImport(tmdbId) { return API.get(`/api/tmdb/import/${tmdbId}/`); },
  };


  // ═══════════════════════════════════════════════════════════════════════════
  // 3. HERO SECTION
  // ═══════════════════════════════════════════════════════════════════════════

  const Hero = {
    async load() {
      const { ok, data } = await API.movies({ filter: 'featured', page: 1 });
      if (!ok || !data.movies?.length) {
        // Fall back to top-rated
        const fallback = await API.movies({ filter: 'top_rated', page: 1 });
        if (!fallback.ok || !fallback.data.movies?.length) return;
        Hero.render(fallback.data.movies[0]);
      } else {
        Hero.render(data.movies[0]);
      }
    },

    render(movie) {
      state.featuredMovie = movie;

      const bg    = document.getElementById('hero-bg');
      const title = document.getElementById('hero-title');
      const meta  = document.getElementById('hero-meta');
      const desc  = document.getElementById('hero-desc');

      if (movie.backdrop_url || movie.poster_url) {
        bg.style.backgroundImage = `url('${movie.backdrop_url || movie.poster_url}')`;
      }

      title.textContent = movie.title;
      desc.textContent  = movie.description
        ? movie.description.slice(0, 180) + (movie.description.length > 180 ? '…' : '')
        : 'No description available.';

      meta.innerHTML = `
        <span class="meta-pill meta-rating">★ ${movie.rating.toFixed(1)}</span>
        <span class="meta-pill">${movie.release_year}</span>
        <span class="meta-pill">${capitalise(movie.genre)}</span>
        ${movie.duration_min ? `<span class="meta-pill">${formatDuration(movie.duration_min)}</span>` : ''}
      `;

      const hero = document.querySelector('.hero');
      requestAnimationFrame(() => hero.classList.add('loaded'));
    },

    bindButtons() {
      document.getElementById('hero-play-btn').addEventListener('click', () => {
        if (state.featuredMovie) Modal.open(state.featuredMovie.id);
      });
      document.getElementById('hero-wl-btn').addEventListener('click', async () => {
        if (!state.user) { AuthModal.open('login'); return; }
        if (!state.featuredMovie) return;
        const { ok, data } = await API.toggleWatchlist(state.featuredMovie.id);
        if (ok) {
          Toast.show(data.action === 'added' ? 'success' : 'info',
            data.action === 'added' ? 'Added to Watchlist' : 'Removed from Watchlist',
            state.featuredMovie.title
          );
          updateWatchlistCount(data.count);
        }
      });
    },
  };


  // ═══════════════════════════════════════════════════════════════════════════
  // 4. MOVIE CARD FACTORY
  // ═══════════════════════════════════════════════════════════════════════════

  function buildMovieCard(movie) {
    const card = document.createElement('div');
    card.className  = 'movie-card';
    card.dataset.id = movie.id;

    const posterContent = movie.poster_url
      ? `<img class="card-img" src="${movie.poster_url}" alt="${escapeHtml(movie.title)}" loading="lazy" />`
      : `<div class="card-no-poster">🎬<span>${capitalise(movie.genre)}</span></div>`;

    const wlBtnText  = movie.in_watchlist ? '✓ Saved' : '+ Watchlist';
    const wlBtnClass = movie.in_watchlist ? 'btn-wl in-wl' : 'btn-wl';

    card.innerHTML = `
      <div class="card-poster">
        ${posterContent}
        <div class="card-overlay">
          <button class="card-poster-btn ${wlBtnClass}" data-action="watchlist">${wlBtnText}</button>
          <button class="card-poster-btn btn-details" data-action="details">Details</button>
        </div>
      </div>
      <div class="card-body">
        <div class="card-genre-row">
          <span class="card-genre genre-${movie.genre}">${capitalise(movie.genre)}</span>
          <span class="card-rating">★ ${movie.rating.toFixed(1)}</span>
        </div>
        <div class="card-title" title="${escapeHtml(movie.title)}">${escapeHtml(movie.title)}</div>
        <div class="card-year">${movie.release_year}</div>
      </div>
    `;

    // Detail click — card body or details button
    card.querySelector('.card-body').addEventListener('click', () => Modal.open(movie.id));
    card.querySelector('[data-action="details"]').addEventListener('click', (e) => {
      e.stopPropagation();
      Modal.open(movie.id);
    });

    // Watchlist toggle
    card.querySelector('[data-action="watchlist"]').addEventListener('click', async (e) => {
      e.stopPropagation();
      if (!state.user) { AuthModal.open('login'); return; }
      const btn = e.currentTarget;
      btn.disabled = true;
      const { ok, data } = await API.toggleWatchlist(movie.id);
      if (ok) {
        movie.in_watchlist = data.in_watchlist;
        btn.textContent    = data.in_watchlist ? '✓ Saved' : '+ Watchlist';
        btn.className      = `card-poster-btn ${data.in_watchlist ? 'btn-wl in-wl' : 'btn-wl'}`;
        Toast.show(
          data.action === 'added' ? 'success' : 'info',
          data.action === 'added' ? 'Added to Watchlist' : 'Removed',
          movie.title
        );
        updateWatchlistCount(data.count);
      }
      btn.disabled = false;
    });

    return card;
  }


  // ═══════════════════════════════════════════════════════════════════════════
  // 5. GRIDS MODULE
  // ═══════════════════════════════════════════════════════════════════════════

  const Grids = {
    async loadAll() {
      await Promise.all([
        Grids.loadRecommend(),
        Grids.loadTrending(),
        Grids.loadMovies(),
      ]);
    },

    async loadRecommend() {
      const grid = document.getElementById('grid-recommend');
      grid.innerHTML = '<div class="loading-state"><div class="spinner"></div><p>Personalising…</p></div>';
      const { ok, data } = await API.recommend();
      if (!ok) { grid.innerHTML = buildEmpty('⚠', 'Could not load', ''); return; }
      document.getElementById('recommend-basis').textContent = data.basis || '';
      renderMoviesToGrid(grid, data.movies);
    },

    async loadTrending() {
      const grid = document.getElementById('grid-trending');
      grid.innerHTML = '<div class="loading-state"><div class="spinner"></div></div>';
      const { ok, data } = await API.trending();
      if (!ok || !data.movies?.length) {
        grid.innerHTML = buildEmpty('🔥', 'Nothing trending yet', 'Mark movies as trending in the admin panel.');
        return;
      }
      renderMoviesToGrid(grid, data.movies);
    },

    async loadMovies(page = 1) {
      state.currentPage = page;
      const grid = document.getElementById('grid-all');
      grid.innerHTML = '<div class="loading-state"><div class="spinner"></div></div>';

      const params = { page };
      if (state.currentGenre)  params.genre = state.currentGenre;
      if (state.currentSearch) params.q     = state.currentSearch;

      const { ok, data } = await API.movies(params);

      const titleEl = document.getElementById('all-movies-title');
      if (state.currentSearch) {
        titleEl.textContent = `Results for "${state.currentSearch}"`;
      } else if (state.currentGenre) {
        titleEl.textContent = `${capitalise(state.currentGenre)} Movies`;
      } else {
        titleEl.textContent = 'All Movies';
      }

      if (!ok || !data.movies?.length) {
        grid.innerHTML = buildEmpty('🔍', 'No movies found', 'Try a different search or genre.');
        document.getElementById('pagination').innerHTML = '';
        return;
      }

      renderMoviesToGrid(grid, data.movies);
      state.totalPages = data.pages;
      Grids.renderPagination(data.pages, page);
    },

    renderPagination(total, current) {
      const el = document.getElementById('pagination');
      if (total <= 1) { el.innerHTML = ''; return; }

      let html = '';
      for (let i = 1; i <= total; i++) {
        html += `<button class="page-btn ${i === current ? 'active' : ''}" data-page="${i}">${i}</button>`;
      }
      el.innerHTML = html;
      el.querySelectorAll('.page-btn').forEach(btn => {
        btn.addEventListener('click', () => Grids.loadMovies(+btn.dataset.page));
      });
    },
  };


  // ═══════════════════════════════════════════════════════════════════════════
  // 6. MOVIE DETAIL MODAL
  // ═══════════════════════════════════════════════════════════════════════════

  const Modal = {
    el: null,

    init() {
      Modal.el = document.getElementById('movie-modal');
      document.getElementById('modal-close-btn').addEventListener('click', Modal.close);
      Modal.el.addEventListener('click', e => { if (e.target === Modal.el) Modal.close(); });

      // Star picker
      document.getElementById('star-picker').addEventListener('click', async e => {
        const star = e.target.closest('.star');
        if (!star) return;
        if (!state.user) { AuthModal.open('login'); return; }
        const val = +star.dataset.val;
        Modal.highlightStars(val);
        const { ok } = await API.rateMovie(state.openModalId, val);
        if (ok) Toast.show('success', 'Rating Saved', `You gave it ${val} star${val > 1 ? 's' : ''}.`);
      });

      // Watchlist button inside modal
      document.getElementById('modal-wl-btn').addEventListener('click', async () => {
        if (!state.user) { AuthModal.open('login'); return; }
        const { ok, data } = await API.toggleWatchlist(state.openModalId);
        if (ok) {
          const btn = document.getElementById('modal-wl-btn');
          btn.textContent = data.in_watchlist ? '✓ In Watchlist' : '+ Watchlist';
          Toast.show(
            data.action === 'added' ? 'success' : 'info',
            data.action === 'added' ? 'Added' : 'Removed',
            ''
          );
          updateWatchlistCount(data.count);
        }
      });

      // AI Suggest button
      document.getElementById('modal-suggest-btn').addEventListener('click', async () => {
        const panel = document.getElementById('suggest-panel');
        const grid  = document.getElementById('suggest-grid');
        const expEl = document.getElementById('suggest-explanation');

        if (!panel.classList.contains('hidden')) {
          panel.classList.add('hidden');
          return;
        }

        grid.innerHTML = '<div class="loading-state"><div class="spinner"></div></div>';
        panel.classList.remove('hidden');

        const { ok, data } = await API.aiSuggest(state.openModalId);
        if (!ok) {
          grid.innerHTML = '<p style="color:var(--text-3);font-size:0.8rem">Could not load suggestions.</p>';
          return;
        }

        expEl.textContent = data.explanation;
        grid.innerHTML    = '';
        data.suggestions.forEach(m => {
          const card = document.createElement('div');
          card.className = 'suggest-card';
          card.innerHTML = m.poster_url
            ? `<img src="${m.poster_url}" alt="${escapeHtml(m.title)}" loading="lazy" />`
            : `<div style="aspect-ratio:2/3;display:flex;align-items:center;justify-content:center;font-size:1.5rem;background:var(--bg-card2)">🎬</div>`;
          card.innerHTML += `<div class="suggest-card-title">${escapeHtml(m.title)}</div>`;
          card.addEventListener('click', () => { Modal.close(); setTimeout(() => Modal.open(m.id), 200); });
          grid.appendChild(card);
        });
      });
    },

    async open(movieId) {
      state.openModalId = movieId;
      const overlay = document.getElementById('movie-modal');
      overlay.classList.remove('hidden');
      document.body.style.overflow = 'hidden';

      // Reset
      document.getElementById('suggest-panel').classList.add('hidden');
      Modal.highlightStars(0);

      // Fetch detail
      const { ok, data } = await API.movieDetail(movieId);
      if (!ok) { Toast.show('error', 'Error', 'Could not load movie details.'); Modal.close(); return; }

      // Backdrop
      const backdropEl = document.getElementById('modal-backdrop');
      backdropEl.src   = data.backdrop_url || data.poster_url || '';
      backdropEl.alt   = data.title;
      backdropEl.style.display = (data.backdrop_url || data.poster_url) ? 'block' : 'none';

      // Poster
      const posterEl = document.getElementById('modal-poster');
      posterEl.src = data.poster_url || '';
      posterEl.style.display = data.poster_url ? 'block' : 'none';

      document.getElementById('modal-title').textContent = data.title;
      document.getElementById('modal-rating').textContent = data.rating.toFixed(1);
      document.getElementById('modal-desc').textContent   = data.description || 'No description available.';

      // Meta tags
      const metaEl = document.getElementById('modal-meta');
      metaEl.innerHTML = [
        data.release_year,
        capitalise(data.genre),
        data.duration_min ? formatDuration(data.duration_min) : null,
        data.director    ? `Dir. ${data.director}` : null,
        `${data.vote_count.toLocaleString()} votes`,
      ].filter(Boolean).map(t => `<span class="meta-tag">${escapeHtml(String(t))}</span>`).join('');

      // Cast
      const castWrap = document.getElementById('modal-cast-wrap');
      const castEl   = document.getElementById('modal-cast');
      if (data.cast?.length) {
        castEl.textContent = data.cast.join(', ');
        castWrap.style.display = 'flex';
      } else {
        castWrap.style.display = 'none';
      }

      // Watchlist button
      const wlBtn = document.getElementById('modal-wl-btn');
      wlBtn.textContent = data.in_watchlist ? '✓ In Watchlist' : '+ Watchlist';

      // Star rating
      if (data.my_rating) Modal.highlightStars(data.my_rating);
    },

    close() {
      document.getElementById('movie-modal').classList.add('hidden');
      document.body.style.overflow = '';
      state.openModalId = null;
    },

    highlightStars(val) {
      document.querySelectorAll('#star-picker .star').forEach(s => {
        s.classList.toggle('lit', +s.dataset.val <= val);
      });
    },
  };


  // ═══════════════════════════════════════════════════════════════════════════
  // 7. WATCHLIST MODAL
  // ═══════════════════════════════════════════════════════════════════════════

  const WatchlistModal = {
    init() {
      document.getElementById('wl-modal-close').addEventListener('click', WatchlistModal.close);
      document.getElementById('watchlist-modal').addEventListener('click', e => {
        if (e.target === document.getElementById('watchlist-modal')) WatchlistModal.close();
      });

      document.querySelectorAll('.js-open-watchlist').forEach(el => {
        el.addEventListener('click', (e) => { e.preventDefault(); WatchlistModal.open(); });
      });
    },

    async open() {
      if (!state.user) { AuthModal.open('login'); return; }
      const overlay = document.getElementById('watchlist-modal');
      overlay.classList.remove('hidden');
      document.body.style.overflow = 'hidden';
      await WatchlistModal.load();
    },

    close() {
      document.getElementById('watchlist-modal').classList.add('hidden');
      document.body.style.overflow = '';
    },

    async load() {
      const content = document.getElementById('watchlist-content');
      content.innerHTML = '<div class="loading-state"><div class="spinner"></div></div>';
      const { ok, data } = await API.watchlist();
      if (!ok) { content.innerHTML = buildEmpty('⚠', 'Error', 'Could not load watchlist.'); return; }

      document.getElementById('wl-count-label').textContent = `${data.count} movie${data.count !== 1 ? 's' : ''}`;

      if (!data.watchlist?.length) {
        content.innerHTML = buildEmpty('🎬', 'Watchlist is Empty', 'Browse movies and hit "+ Watchlist" to save them here.');
        return;
      }

      const list = document.createElement('div');
      list.className = 'watchlist-list';

      data.watchlist.forEach(movie => {
        const item = document.createElement('div');
        item.className  = `wl-item ${movie.is_watched ? 'is-watched' : ''}`;
        item.dataset.id = movie.id;

        item.innerHTML = `
          <img class="wl-poster"
               src="${movie.poster_url || ''}"
               alt="${escapeHtml(movie.title)}"
               onerror="this.style.display='none'"
          />
          <div class="wl-info">
            <div class="wl-title">${escapeHtml(movie.title)}</div>
            <div class="wl-meta">
              ${capitalise(movie.genre)} · ${movie.release_year} · ★${movie.rating.toFixed(1)}
            </div>
          </div>
          <div class="wl-actions">
            <button class="wl-btn watched-btn ${movie.is_watched ? 'active' : ''}" data-action="watched">
              ${movie.is_watched ? '✓ Watched' : 'Mark Watched'}
            </button>
            <button class="wl-btn" data-action="detail">Details</button>
            <button class="wl-btn remove" data-action="remove">Remove</button>
          </div>
        `;

        item.querySelector('[data-action="watched"]').addEventListener('click', async () => {
          const { ok, data: d } = await API.markWatched(movie.id);
          if (ok) {
            item.classList.toggle('is-watched', d.is_watched);
            item.querySelector('[data-action="watched"]').textContent = d.is_watched ? '✓ Watched' : 'Mark Watched';
            item.querySelector('[data-action="watched"]').classList.toggle('active', d.is_watched);
          }
        });

        item.querySelector('[data-action="detail"]').addEventListener('click', () => {
          WatchlistModal.close();
          setTimeout(() => Modal.open(movie.id), 200);
        });

        item.querySelector('[data-action="remove"]').addEventListener('click', async () => {
          const { ok } = await API.toggleWatchlist(movie.id);
          if (ok) {
            item.style.animation = 'toastOut 0.3s ease forwards';
            setTimeout(() => WatchlistModal.load(), 400);
            Toast.show('info', 'Removed from Watchlist', movie.title);
          }
        });

        list.appendChild(item);
      });

      content.innerHTML = '';
      content.appendChild(list);
    },
  };


  // ═══════════════════════════════════════════════════════════════════════════
  // 8. AUTH MODAL
  // ═══════════════════════════════════════════════════════════════════════════

  const AuthModal = {
    currentMode: 'login',

    init() {
      document.getElementById('auth-modal-close').addEventListener('click', AuthModal.close);
      document.getElementById('auth-modal').addEventListener('click', e => {
        if (e.target === document.getElementById('auth-modal')) AuthModal.close();
      });

      document.querySelectorAll('.js-open-login').forEach(el => {
        el.addEventListener('click', () => AuthModal.open('login'));
      });
      document.querySelectorAll('.js-open-register').forEach(el => {
        el.addEventListener('click', () => AuthModal.open('register'));
      });

      document.getElementById('auth-form').addEventListener('submit', async (e) => {
        e.preventDefault();
        const btn      = document.getElementById('auth-submit-btn');
        const errEl    = document.getElementById('auth-error');
        const username = document.getElementById('auth-username').value.trim();
        const password = document.getElementById('auth-password').value;
        const email    = document.getElementById('auth-email').value.trim();

        btn.textContent = 'Loading…';
        btn.disabled    = true;
        errEl.classList.add('hidden');

        let res;
        if (AuthModal.currentMode === 'login') {
          res = await API.login(username, password);
        } else {
          res = await API.register(username, email, password);
        }

        btn.disabled    = false;
        btn.textContent = AuthModal.currentMode === 'login' ? 'Sign In' : 'Create Account';

        if (res.ok) {
          state.user = { username: res.data.username };
          updateNavForUser(res.data.username);
          AuthModal.close();
          Toast.show('success', `Welcome, ${res.data.username}!`, '');
          checkAuthStatus(); // Refresh watchlist count
        } else {
          errEl.textContent = res.data.error || 'Something went wrong.';
          errEl.classList.remove('hidden');
        }
      });

      document.getElementById('logout-btn').addEventListener('click', async () => {
        await fetch('/logout/');
        state.user = null;
        updateNavForGuest();
        Toast.show('info', 'Signed out', '');
        Grids.loadAll();
      });
    },

    open(mode = 'login') {
      AuthModal.switchAuthTab(mode);
      document.getElementById('auth-modal').classList.remove('hidden');
      document.body.style.overflow = 'hidden';
      setTimeout(() => document.getElementById('auth-username').focus(), 100);
    },

    close() {
      document.getElementById('auth-modal').classList.add('hidden');
      document.body.style.overflow = '';
    },
  };

  // Exposed globally for inline onclick in HTML
  function switchAuthTab(mode) {
    AuthModal.currentMode = mode;
    const tabLogin    = document.getElementById('tab-login');
    const tabRegister = document.getElementById('tab-register');
    const regFields   = document.getElementById('register-fields');
    const submitBtn   = document.getElementById('auth-submit-btn');

    if (mode === 'login') {
      tabLogin.classList.add('active');
      tabRegister.classList.remove('active');
      regFields.classList.add('hidden');
      submitBtn.textContent = 'Sign In';
    } else {
      tabLogin.classList.remove('active');
      tabRegister.classList.add('active');
      regFields.classList.remove('hidden');
      submitBtn.textContent = 'Create Account';
    }
  }


  // ═══════════════════════════════════════════════════════════════════════════
  // 9. ADD MOVIE MODAL
  // ═══════════════════════════════════════════════════════════════════════════

  const AddMovieModal = {
    init() {
      document.getElementById('add-movie-close').addEventListener('click', AddMovieModal.close);
      document.getElementById('add-movie-modal').addEventListener('click', e => {
        if (e.target === document.getElementById('add-movie-modal')) AddMovieModal.close();
      });

      document.querySelectorAll('.js-open-add-modal').forEach(el => {
        el.addEventListener('click', AddMovieModal.open);
      });

      // TMDB search
      let tmdbDebounce;
      document.getElementById('tmdb-search-btn').addEventListener('click', AddMovieModal.searchTMDB);
      document.getElementById('tmdb-search-input').addEventListener('keydown', e => {
        if (e.key === 'Enter') AddMovieModal.searchTMDB();
      });

      // Manual form
      document.getElementById('add-movie-form').addEventListener('submit', async (e) => {
        e.preventDefault();
        const btn = document.getElementById('add-movie-submit');
        btn.textContent = 'Adding…';
        btn.disabled    = true;

        const payload = {
          title:        document.getElementById('new-title').value.trim(),
          genre:        document.getElementById('new-genre').value,
          description:  document.getElementById('new-desc').value.trim(),
          release_year: document.getElementById('new-year').value,
          rating:       document.getElementById('new-rating').value,
          poster_url:   document.getElementById('new-poster').value.trim(),
          is_featured:  document.getElementById('new-featured').checked,
          is_trending:  document.getElementById('new-trending').checked,
        };

        const { ok, data } = await API.addMovie(payload);
        btn.textContent = 'Add Movie';
        btn.disabled    = false;

        if (ok) {
          Toast.show('success', 'Movie Added', payload.title);
          AddMovieModal.close();
          Grids.loadMovies();
        } else {
          Toast.show('error', 'Error', data.error || 'Could not add movie.');
        }
      });
    },

    open() {
      document.getElementById('add-movie-modal').classList.remove('hidden');
      document.body.style.overflow = 'hidden';
    },

    close() {
      document.getElementById('add-movie-modal').classList.add('hidden');
      document.body.style.overflow = '';
    },

    async searchTMDB() {
      const q = document.getElementById('tmdb-search-input').value.trim();
      if (!q) return;
      const resultsEl = document.getElementById('tmdb-results');
      resultsEl.innerHTML = '<div style="color:var(--text-3);font-size:0.8rem;padding:0.5rem">Searching TMDB…</div>';

      const { ok, data } = await API.tmdbSearch(q);
      if (!ok || !data.results?.length) {
        resultsEl.innerHTML = '<div style="color:var(--text-3);font-size:0.8rem;padding:0.5rem">No results. Check your TMDB API key.</div>';
        return;
      }

      resultsEl.innerHTML = '';
      data.results.forEach(item => {
        const el = document.createElement('div');
        el.className = 'tmdb-result-item';
        el.innerHTML = `
          ${item.poster_url
            ? `<img class="tmdb-thumb" src="${item.poster_url}" alt="${escapeHtml(item.title)}" />`
            : `<div class="tmdb-thumb" style="display:flex;align-items:center;justify-content:center;font-size:1.2rem">🎬</div>`
          }
          <div class="tmdb-result-info">
            <div class="tmdb-result-title">${escapeHtml(item.title)}</div>
            <div class="tmdb-result-meta">${item.release_year} · ${capitalise(item.genre)} · ★${item.rating.toFixed(1)}</div>
          </div>
          <button class="btn btn-primary btn-sm" style="margin-left:auto;flex-shrink:0">Import</button>
        `;
        el.querySelector('button').addEventListener('click', async () => {
          el.querySelector('button').textContent = '…';
          const { ok, data: d } = await API.tmdbImport(item.tmdb_id);
          if (ok) {
            Toast.show('success', d.imported ? 'Imported from TMDB' : 'Already in DB', d.movie.title);
            AddMovieModal.close();
            Grids.loadMovies();
          } else {
            Toast.show('error', 'Import Failed', d.error || '');
          }
        });
        resultsEl.appendChild(el);
      });
    },
  };


  // ═══════════════════════════════════════════════════════════════════════════
  // 10. TOAST NOTIFICATIONS
  // ═══════════════════════════════════════════════════════════════════════════

  const Toast = {
    icons: { success: '✓', error: '✕', info: 'ℹ' },

    show(type, title, message, duration = 3500) {
      const container = document.getElementById('toast-container');
      const toast     = document.createElement('div');
      toast.className = `toast ${type}`;
      toast.innerHTML = `
        <span class="toast-icon">${Toast.icons[type] || 'ℹ'}</span>
        <div class="toast-text">
          <div class="toast-title">${escapeHtml(title)}</div>
          ${message ? `<div class="toast-msg">${escapeHtml(String(message))}</div>` : ''}
        </div>
      `;
      container.appendChild(toast);

      setTimeout(() => {
        toast.classList.add('out');
        setTimeout(() => toast.remove(), 350);
      }, duration);
    },
  };


  // ═══════════════════════════════════════════════════════════════════════════
  // 11. EVENTS
  // ═══════════════════════════════════════════════════════════════════════════

  const Events = {
    init() {
      // Navbar scroll effect
      window.addEventListener('scroll', () => {
        document.getElementById('navbar').classList.toggle('scrolled', window.scrollY > 30);
      });

      // Genre filter
      document.getElementById('genre-filter').addEventListener('click', e => {
        const pill = e.target.closest('.filter-pill');
        if (!pill) return;
        document.querySelectorAll('.filter-pill').forEach(p => p.classList.remove('active'));
        pill.classList.add('active');
        state.currentGenre  = pill.dataset.genre;
        state.currentSearch = '';
        document.getElementById('search-input').value = '';
        Grids.loadMovies(1);
      });

      // Search (real-time with debounce)
      document.getElementById('search-input').addEventListener('input', e => {
        clearTimeout(state.searchDebounce);
        state.searchDebounce = setTimeout(() => {
          state.currentSearch = e.target.value.trim();
          state.currentGenre  = '';
          document.querySelectorAll('.filter-pill').forEach(p => p.classList.remove('active'));
          document.querySelector('.filter-pill[data-genre=""]').classList.add('active');
          Grids.loadMovies(1);
        }, 350);
      });

      // Keyboard shortcut: Escape closes any open modal
      document.addEventListener('keydown', e => {
        if (e.key !== 'Escape') return;
        Modal.close();
        WatchlistModal.close();
        AuthModal.close();
        AddMovieModal.close();
      });
    },
  };


  // ═══════════════════════════════════════════════════════════════════════════
  // 12. INIT
  // ═══════════════════════════════════════════════════════════════════════════

  async function init() {
    // Check auth session
    await checkAuthStatus();

    // Boot all UI modules
    Hero.load();
    Hero.bindButtons();
    Modal.init();
    WatchlistModal.init();
    AuthModal.init();
    AddMovieModal.init();
    Events.init();

    // Load all grids
    await Grids.loadAll();
  }

  async function checkAuthStatus() {
    const { ok, data } = await API.authStatus();
    if (ok && data.authenticated) {
      state.user = { username: data.username };
      updateNavForUser(data.username, data.watchlist_count);
    } else {
      state.user = null;
      updateNavForGuest();
    }
  }


  // ═══════════════════════════════════════════════════════════════════════════
  // UTILITIES
  // ═══════════════════════════════════════════════════════════════════════════

  function updateNavForUser(username, wlCount = 0) {
    document.getElementById('nav-auth').classList.add('hidden');
    document.getElementById('nav-user').classList.remove('hidden');
    document.getElementById('user-name').textContent   = username;
    document.getElementById('user-avatar').textContent = username.charAt(0).toUpperCase();
    updateWatchlistCount(wlCount);
  }

  function updateNavForGuest() {
    document.getElementById('nav-auth').classList.remove('hidden');
    document.getElementById('nav-user').classList.add('hidden');
    updateWatchlistCount(0);
  }

  function updateWatchlistCount(count) {
    const badge = document.getElementById('nav-wl-count');
    if (count > 0) {
      badge.textContent    = count;
      badge.style.display  = 'inline-flex';
    } else {
      badge.style.display  = 'none';
    }
  }

  function renderMoviesToGrid(grid, movies) {
    grid.innerHTML = '';
    if (!movies?.length) {
      grid.innerHTML = buildEmpty('🎬', 'No movies found', '');
      return;
    }
    movies.forEach(m => grid.appendChild(buildMovieCard(m)));
  }

  function buildEmpty(icon, title, msg) {
    return `
      <div class="empty-state">
        <div class="empty-icon">${icon}</div>
        <h3>${escapeHtml(title)}</h3>
        <p>${escapeHtml(msg)}</p>
      </div>
    `;
  }

  function capitalise(str) {
    if (!str) return '';
    return str.charAt(0).toUpperCase() + str.slice(1);
  }

  function formatDuration(minutes) {
    const h = Math.floor(minutes / 60);
    const m = minutes % 60;
    return h ? `${h}h ${m}m` : `${m}m`;
  }

  function escapeHtml(str) {
    if (typeof str !== 'string') return String(str || '');
    return str
      .replace(/&/g, '&amp;')
      .replace(/</g, '&lt;')
      .replace(/>/g, '&gt;')
      .replace(/"/g, '&quot;')
      .replace(/'/g, '&#039;');
  }

  function getCookie(name) {
    const cookies = document.cookie.split(';');
    for (const c of cookies) {
      const [k, v] = c.trim().split('=');
      if (k === name) return decodeURIComponent(v);
    }
    return '';
  }

  // ── Public surface ──────────────────────────────────────────────────────
  return {
    init,
    switchAuthTab,
    Toast,
  };

})();

// Bootstrap when DOM is ready
document.addEventListener('DOMContentLoaded', MOVIX.init);
