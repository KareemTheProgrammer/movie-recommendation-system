# 🎬 MOVIX — Smart AI Movie Recommendation Platform

> A full-stack, production-quality movie platform built with Django, vanilla JS,
> TMDB API integration, and an AI-powered recommendation engine.
> Designed as a university capstone project.

---

## Table of Contents

1. [What Was Built](#what-was-built)
2. [Project Architecture](#project-architecture)
3. [Technology Stack](#technology-stack)
4. [Feature List](#feature-list)
5. [Installation & Setup](#installation--setup)
6. [Configuration (API Keys)](#configuration-api-keys)
7. [Running the Server](#running-the-server)
8. [API Reference](#api-reference)
9. [How the AI Works](#how-the-ai-works)
10. [Figma Design Specification](#figma-design-specification)
11. [How to Present This Project](#how-to-present-this-project)

---

## What Was Built

MOVIX is a cinematic-dark-themed movie recommendation web application.
A user lands on a hero-driven homepage, browses a catalogue of films,
searches in real-time, filters by genre, opens a full detail modal for
any movie, saves films to a personal watchlist, rates them 1–5 stars,
and receives intelligent personalised recommendations—all without a
single page reload.

The backend is a Django REST-style application that exposes JSON
endpoints consumed by a vanilla JavaScript frontend. The database is
SQLite (zero configuration required). External data comes from The Movie
Database (TMDB) API. Optional AI explanations use the OpenAI API.

---

## Project Architecture

```
movix/
│
├── manage.py                        ← Django entry point
├── requirements.txt                 ← Python dependencies (just Django)
├── db.sqlite3                       ← Auto-created after first migrate
│
├── movix_project/                   ← Django project configuration
│   ├── settings.py                  ← All settings (DB, static, API keys)
│   ├── urls.py                      ← Root URL routing
│   └── wsgi.py
│
├── movix_app/                       ← Main application
│   ├── models.py                    ← Movie, Watchlist, UserRating, UserProfile
│   ├── views.py                     ← All page views + JSON API endpoints
│   ├── urls.py                      ← App-level URL patterns
│   ├── admin.py                     ← Admin panel customisation
│   ├── apps.py
│   ├── migrations/
│   └── management/
│       └── commands/
│           └── seed_movies.py       ← `python manage.py seed_movies`
│
├── templates/
│   └── movix/
│       ├── index.html               ← Main homepage SPA shell
│       ├── watchlist.html           ← Dedicated watchlist page
│       └── auth.html                ← Login / register page
│
└── static/
    ├── css/
    │   └── movix.css                ← Complete cinematic stylesheet
    └── js/
        └── movix.js                 ← All frontend logic (vanilla JS)
```

**Data flow:**
```
Browser  ──fetch()──►  Django views.py  ──ORM──►  SQLite
                            │
                            ├──► TMDB API (movie data / import)
                            └──► OpenAI API (AI explanations, optional)
```

---

## Technology Stack

| Layer      | Technology          | Why                                  |
|------------|---------------------|--------------------------------------|
| Backend    | Django 4.2          | Batteries-included, simple ORM       |
| Database   | SQLite              | Zero-config, ships with Python       |
| Frontend   | Vanilla JS (ES6+)   | No build step, easy to explain       |
| Styling    | Custom CSS (vars)   | Full control, cinematic design       |
| Fonts      | Bebas Neue / DM Sans| Cinematic display + clean body       |
| Movie Data | TMDB API            | Free, comprehensive, real posters    |
| AI         | OpenAI GPT-3.5      | Readable recommendations (optional)  |
| Auth       | Django Sessions     | Built-in, secure                     |

---

## Feature List

### Frontend
- [x] Cinematic dark hero section with backdrop image
- [x] Real-time search with 350ms debounce
- [x] Genre filter pills (11 genres)
- [x] Movie card grid with hover overlay
- [x] Movie detail modal (backdrop, poster, cast, trailer link)
- [x] Add to / remove from watchlist (per-card + modal button)
- [x] 1–5 star rating widget
- [x] AI "Find Similar" panel inside detail modal
- [x] Watchlist modal with watched/unwatched toggle
- [x] Toast notification system (success / error / info)
- [x] Loading spinners + empty states
- [x] Add Movie form (manual + TMDB search/import)
- [x] Login / Register modal with tab switcher
- [x] Navbar watchlist counter badge
- [x] Pagination for All Movies grid
- [x] Smooth CSS animations throughout
- [x] Fully responsive (mobile-friendly)

### Backend (Django)
- [x] User registration & login via sessions
- [x] Movie CRUD (list, detail, add, delete)
- [x] Watchlist add / remove / toggle
- [x] Mark movie as watched
- [x] 1–5 star user rating (stored per user)
- [x] Rule-based recommendation engine
- [x] TMDB search proxy endpoint
- [x] TMDB movie import (full detail, cast, trailer)
- [x] AI suggestion endpoint (OpenAI + rule-based fallback)
- [x] Auth status check endpoint
- [x] Django admin panel with movie management

---

## Installation & Setup

### Prerequisites
- Python 3.9 or higher
- pip
- Internet connection (for Google Fonts + TMDB images)

### Step 1 — Clone / unzip the project

```bash
# If you have git:
git clone <your-repo-url> movix
cd movix

# Or simply unzip and cd into the folder
```

### Step 2 — Create a virtual environment (recommended)

```bash
python -m venv venv

# Activate it:
# macOS / Linux:
source venv/bin/activate
# Windows:
venv\Scripts\activate
```

### Step 3 — Install dependencies

```bash
pip install -r requirements.txt
```

This installs only Django — no other libraries needed.

### Step 4 — Create the database

```bash
python manage.py makemigrations
python manage.py migrate
```

### Step 5 — Seed with demo movies

```bash
python manage.py seed_movies
```

This inserts 25 real movies with TMDB poster URLs so the app looks
visually complete immediately, without any API key.

### Step 6 — Create an admin account

```bash
python manage.py createsuperuser
```

Follow the prompts (username, email, password).

---

## Configuration (API Keys)

Open `movix_project/settings.py` and set:

```python
# Line ~55 — get a free key at https://www.themoviedb.org/settings/api
TMDB_API_KEY = 'YOUR_TMDB_API_KEY_HERE'

# Optional — enables AI explanations on "Find Similar"
OPENAI_API_KEY = 'sk-...'
```

Or set them as environment variables (more secure):

```bash
export TMDB_API_KEY=your_tmdb_key
export OPENAI_API_KEY=your_openai_key
```

**The app works without any API keys** — you just won't be able to
import new movies from TMDB or get OpenAI explanations. The 25 seeded
movies (with TMDB image URLs) load fine with no key at all.

---

## Running the Server

```bash
python manage.py runserver
```

Open your browser at: **http://127.0.0.1:8000**

Admin panel: **http://127.0.0.1:8000/admin**

---

## API Reference

All endpoints return JSON. POST bodies are JSON-encoded.

| Method | URL                          | Auth? | Description                        |
|--------|------------------------------|-------|------------------------------------|
| GET    | `/api/movies/`               | No    | List movies. Params: `q`, `genre`, `filter`, `page` |
| GET    | `/api/movies/<id>/`          | No    | Single movie detail                |
| POST   | `/api/movies/add/`           | No    | Add a movie manually               |
| POST   | `/api/movies/delete/<id>/`   | No    | Delete a movie                     |
| GET    | `/api/watchlist/`            | Yes   | User's watchlist                   |
| POST   | `/api/watchlist/toggle/`     | Yes   | Add/remove `{ "movie_id": int }`   |
| POST   | `/api/watchlist/watched/`    | Yes   | Toggle watched `{ "movie_id": int }`|
| POST   | `/api/rate/`                 | Yes   | Rate `{ "movie_id": int, "score": 1–5 }` |
| GET    | `/api/recommend/`            | No    | Personalised recommendations       |
| POST   | `/api/ai/suggest/`           | No    | Find similar `{ "movie_id": int }` |
| GET    | `/api/tmdb/search/?q=term`   | No    | Search TMDB                        |
| GET    | `/api/tmdb/import/<tmdb_id>/`| No    | Import a TMDB movie into DB        |
| POST   | `/login/`                    | No    | `{ "username", "password" }`       |
| POST   | `/register/`                 | No    | `{ "username", "email", "password" }` |
| GET    | `/api/auth/status/`          | No    | Check session status               |

---

## How the AI Works

MOVIX implements a **two-tier recommendation system**:

### Tier 1 — Rule-Based (always active, no API key needed)

Located in `views.py → api_recommend()` and `api_ai_suggest()`.

**Personalised recommendations:**
1. Collect all movies the user has watched or rated ≥ 4 stars.
2. Count genre frequency across those movies.
3. Return top-rated movies from the user's top 3 favourite genres,
   excluding movies they've already interacted with.
4. New users get the top-rated movies overall.

**"Find Similar":**
1. Find all movies of the same genre as the selected movie.
2. Sort by rating, exclude the original.
3. Supplement with extra movies if fewer than 4 results.

### Tier 2 — OpenAI (optional, enhances explanations only)

Located in `views.py → _get_openai_suggestions()`.

When an OpenAI key is set, MOVIX sends a short prompt to
`gpt-3.5-turbo` asking it to generate a one-sentence explanation
of *why* a fan of Movie X would enjoy similar films. This explanation
appears above the suggestion grid in the "Find Similar" panel.

The actual movie cards always come from the database — OpenAI never
invents or hallucinates titles. It only provides the human-readable
explanation. This makes the AI feature **safe, practical, and
explainable** — ideal for a university presentation.

---

## Figma Design Specification

Below is the complete design system to replicate in Figma.

### Colour Palette

| Token          | Hex       | Usage                              |
|----------------|-----------|------------------------------------|
| `--bg-deep`    | `#070b0f` | Page background                    |
| `--bg-card`    | `#0d1117` | Card / modal backgrounds           |
| `--bg-card2`   | `#111820` | Secondary surfaces                 |
| `--accent`     | `#f5a623` | Primary CTA, logo, stars, badges   |
| `--cyan`       | `#00d4ff` | AI feature accent                  |
| `--text-1`     | `#f0f4f8` | Primary text                       |
| `--text-2`     | `#8b97a8` | Secondary / descriptive text       |
| `--text-3`     | `#4a5568` | Placeholder, muted labels          |

### Typography

| Role            | Font          | Weight | Size          |
|-----------------|---------------|--------|---------------|
| Logo / Hero     | Bebas Neue    | 400    | 32–88px       |
| Section titles  | Bebas Neue    | 400    | 26px          |
| Body text       | DM Sans       | 400    | 14–16px       |
| Labels / UI     | DM Sans       | 500–600| 12–14px       |
| Numeric data    | DM Mono       | 400–500| 12–14px       |

### Component System

**Movie Card** (200px wide)
- 2:3 aspect ratio poster
- Hover overlay: two action buttons slide up
- Genre pill (colour-coded per genre) + star rating
- Title + year in card body

**Navbar** (70px tall, sticky, blurs on scroll)
- Logo left · Nav links centre · Search + auth right

**Hero** (95vh)
- Full-bleed backdrop image with gradient overlay
- Badge → Title (Bebas) → Meta row → Description → 2 CTAs

**Modal** (max 680px wide)
- Backdrop image header (260px)
- Poster thumbnail overlapping header/body boundary
- Title, meta tags, rating block, description, cast
- Star picker (1–5) + Watchlist + Find Similar buttons
- Collapsible AI suggestions panel below

**Toast** (bottom-right stack)
- Icon + title + optional subtitle
- Slide-in from right, auto-dismiss after 3.5s

### Layout Grids

- Movie grid: `repeat(auto-fill, minmax(200px, 1fr))`, gap 20px
- Max content width: 1400px, padding 32px
- Mobile breakpoint: 768px → card min-width 150px

---

## How to Present This Project

### Opening (30 seconds)

> "MOVIX is a full-stack web application that combines a cinematic user
> interface, a Django REST backend, a SQLite database, and an
> AI-powered recommendation system — all in a single project you can
> run with one command."

### Walk Through the User Journey (2 minutes)

1. **Show the homepage** — point out the hero, the dark theme, the
   responsive layout.
2. **Search for a movie** — show real-time filtering as you type.
3. **Click a genre pill** — show the grid filtering instantly.
4. **Open a movie modal** — point out the backdrop, poster, meta,
   cast, rating.
5. **Rate the movie** — click the stars, show the toast notification.
6. **Add to watchlist** — show the navbar badge counter update.
7. **Click "Find Similar"** — show the AI panel loading and appearing.
8. **Open the watchlist** — show the saved movies, mark one as watched.

### Explain the Architecture (1 minute)

Draw or show the three-tier diagram:

```
[Browser / HTML+CSS+JS]
         │  fetch() JSON
[Django Views / API]
         │  Django ORM
    [SQLite DB]
         │
    [TMDB API]  ←── movie data, posters
    [OpenAI]    ←── recommendation explanations
```

### Explain the AI (1 minute)

> "There are two layers. The first is rule-based — it looks at what
> genres the user has rated highly and recommends more of those. The
> second layer, if an OpenAI key is provided, generates a human-readable
> explanation for *why* those recommendations make sense. The movies
> always come from our own database — the AI only explains, never
> invents — so there is no hallucination risk."

### Answer Common Questions

**Q: Why Django and not Flask?**
> Django includes an ORM, admin panel, session auth, and URL routing
> out of the box. Flask would require five additional libraries for the
> same result. For a project of this scope, Django is the right choice.

**Q: Why SQLite instead of PostgreSQL?**
> SQLite requires zero installation and is perfectly suitable for
> development and small-to-medium production workloads. Switching to
> PostgreSQL in production is a one-line settings change.

**Q: Why vanilla JavaScript instead of React?**
> React adds a build pipeline, node_modules, and framework-specific
> concepts. Vanilla JS is easier to audit, debug, and explain in a
> university setting. The MOVIX frontend uses a clean namespace pattern
> that is just as maintainable.

**Q: How does TMDB integration work?**
> TMDB provides a free REST API. Our Django backend acts as a proxy —
> the browser calls `/api/tmdb/search/?q=term`, Django forwards it to
> TMDB, maps the response to our data model, and returns JSON. When
> the user clicks Import, we store the movie permanently in SQLite.

**Q: Is this production-ready?**
> The architecture is production-ready. For a live deployment you would:
> (1) set `DEBUG = False`, (2) switch to PostgreSQL, (3) add HTTPS via
> nginx, (4) run with gunicorn. None of these changes touch the
> application code.
