"""
MOVIX — Database Models

Models defined here:
  - Movie       : Stores all movie data (local + from TMDB)
  - Watchlist   : User's personal watchlist
  - UserRating  : User star ratings for movies
  - UserProfile : Extended profile tied to Django's auth User
"""

from django.db import models
from django.contrib.auth.models import User
from django.core.validators import MinValueValidator, MaxValueValidator


class Movie(models.Model):
    """
    Central movie record. Can be created manually (admin) or pulled
    from TMDB. The tmdb_id field links back to the external source.
    """

    GENRE_CHOICES = [
        ('action',      'Action'),
        ('comedy',      'Comedy'),
        ('drama',       'Drama'),
        ('horror',      'Horror'),
        ('sci-fi',      'Sci-Fi'),
        ('romance',     'Romance'),
        ('thriller',    'Thriller'),
        ('animation',   'Animation'),
        ('documentary', 'Documentary'),
        ('fantasy',     'Fantasy'),
        ('mystery',     'Mystery'),
        ('adventure',   'Adventure'),
    ]

    # ── Core fields ────────────────────────────────────────────────────────────
    title        = models.CharField(max_length=255)
    description  = models.TextField(blank=True)
    genre        = models.CharField(max_length=50, choices=GENRE_CHOICES, default='action')
    release_year = models.IntegerField(default=2024)
    duration_min = models.IntegerField(default=120, help_text='Runtime in minutes')
    director     = models.CharField(max_length=200, blank=True)
    cast_list    = models.TextField(blank=True, help_text='Comma-separated cast names')

    # ── Media ──────────────────────────────────────────────────────────────────
    poster_url   = models.URLField(max_length=500, blank=True)
    backdrop_url = models.URLField(max_length=500, blank=True)
    trailer_url  = models.URLField(max_length=500, blank=True)

    # ── Ratings ────────────────────────────────────────────────────────────────
    rating       = models.FloatField(
        default=0.0,
        validators=[MinValueValidator(0.0), MaxValueValidator(10.0)]
    )
    vote_count   = models.IntegerField(default=0)

    # ── TMDB Integration ───────────────────────────────────────────────────────
    tmdb_id      = models.IntegerField(unique=True, null=True, blank=True)

    # ── Metadata ───────────────────────────────────────────────────────────────
    is_featured  = models.BooleanField(default=False)
    is_trending  = models.BooleanField(default=False)
    created_at   = models.DateTimeField(auto_now_add=True)
    updated_at   = models.DateTimeField(auto_now=True)

    class Meta:
        ordering = ['-rating', '-vote_count']

    def __str__(self):
        return f"{self.title} ({self.release_year})"

    @property
    def star_rating(self):
        """Convert 0–10 TMDB rating to 0–5 star scale."""
        return round(self.rating / 2, 1)

    @property
    def formatted_cast(self):
        return [c.strip() for c in self.cast_list.split(',') if c.strip()]

    def to_dict(self):
        """Serialise to a plain dict for JSON API responses."""
        return {
            'id':           self.id,
            'title':        self.title,
            'description':  self.description,
            'genre':        self.genre,
            'release_year': self.release_year,
            'duration_min': self.duration_min,
            'director':     self.director,
            'cast':         self.formatted_cast,
            'poster_url':   self.poster_url,
            'backdrop_url': self.backdrop_url,
            'trailer_url':  self.trailer_url,
            'rating':       self.rating,
            'star_rating':  self.star_rating,
            'vote_count':   self.vote_count,
            'tmdb_id':      self.tmdb_id,
            'is_featured':  self.is_featured,
            'is_trending':  self.is_trending,
        }


class Watchlist(models.Model):
    """Tracks which movies a user has saved to their personal watchlist."""

    user       = models.ForeignKey(User, on_delete=models.CASCADE, related_name='watchlist')
    movie      = models.ForeignKey(Movie, on_delete=models.CASCADE, related_name='watchlisted_by')
    added_at   = models.DateTimeField(auto_now_add=True)
    is_watched = models.BooleanField(default=False)

    class Meta:
        unique_together = ('user', 'movie')
        ordering = ['-added_at']

    def __str__(self):
        status = '✓' if self.is_watched else '○'
        return f"{status} {self.user.username} → {self.movie.title}"


class UserRating(models.Model):
    """Stores the star rating a specific user gave a specific movie."""

    user   = models.ForeignKey(User, on_delete=models.CASCADE, related_name='ratings')
    movie  = models.ForeignKey(Movie, on_delete=models.CASCADE, related_name='user_ratings')
    score  = models.IntegerField(
        validators=[MinValueValidator(1), MaxValueValidator(5)],
        help_text='1–5 star rating'
    )
    review = models.TextField(blank=True)
    rated_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        unique_together = ('user', 'movie')

    def __str__(self):
        return f"{self.user.username} rated '{self.movie.title}': {self.score}★"


class UserProfile(models.Model):
    """
    Extended profile attached 1-to-1 to Django's built-in User.
    Stores genre preferences used by the recommendation engine.
    """

    user             = models.OneToOneField(User, on_delete=models.CASCADE, related_name='profile')
    avatar_url       = models.URLField(blank=True)
    favourite_genres = models.CharField(
        max_length=500,
        blank=True,
        help_text='Comma-separated genre slugs, e.g. "action,sci-fi,thriller"'
    )
    bio              = models.TextField(blank=True)
    created_at       = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return f"Profile — {self.user.username}"

    @property
    def genre_list(self):
        return [g.strip() for g in self.favourite_genres.split(',') if g.strip()]
