"""
MOVIX — Admin Panel Configuration
"""

from django.contrib import admin
from .models import Movie, Watchlist, UserRating, UserProfile


@admin.register(Movie)
class MovieAdmin(admin.ModelAdmin):
    list_display    = ['title', 'genre', 'rating', 'release_year', 'is_featured', 'is_trending']
    list_filter     = ['genre', 'is_featured', 'is_trending', 'release_year']
    search_fields   = ['title', 'description', 'director']
    list_editable   = ['is_featured', 'is_trending']
    ordering        = ['-rating']
    readonly_fields = ['created_at', 'updated_at']


@admin.register(Watchlist)
class WatchlistAdmin(admin.ModelAdmin):
    list_display = ['user', 'movie', 'is_watched', 'added_at']
    list_filter  = ['is_watched']


@admin.register(UserRating)
class UserRatingAdmin(admin.ModelAdmin):
    list_display = ['user', 'movie', 'score', 'rated_at']


@admin.register(UserProfile)
class UserProfileAdmin(admin.ModelAdmin):
    list_display = ['user', 'favourite_genres', 'created_at']
