"""
MOVIX — Views & API Endpoints

URL pattern overview:
  GET  /                        → homepage
  GET  /watchlist/              → watchlist page
  POST /register/               → create account
  POST /login/                  → authenticate
  POST /logout/                 → sign out

  JSON API:
  GET  /api/movies/             → list movies (search, genre, trending filters)
  GET  /api/movies/<id>/        → single movie detail
  POST /api/movies/add/         → add new movie (admin / demo)
  POST /api/movies/delete/<id>/ → delete a movie
  GET  /api/watchlist/          → user's watchlist
  POST /api/watchlist/toggle/   → add or remove from watchlist
  POST /api/watchlist/watched/  → mark as watched
  POST /api/rate/               → rate a movie 1–5 stars
  GET  /api/recommend/          → AI-powered recommendations
  GET  /api/tmdb/search/        → proxy TMDB search
  GET  /api/tmdb/import/<id>/   → import a TMDB movie into DB
  POST /api/ai/suggest/         → "suggest movies like X"
"""

import json
import urllib.request
import urllib.parse

from django.shortcuts import render, redirect
from django.contrib.auth import login, logout, authenticate
from django.contrib.auth.models import User
from django.contrib.auth.decorators import login_required
from django.views.decorators.http import require_http_methods
from django.views.decorators.csrf import csrf_exempt
from django.http import JsonResponse
from django.conf import settings
from django.db.models import Q, Avg

from .models import Movie, Watchlist, UserRating, UserProfile


# ──────────────────────────────────────────────────────────────────────────────
# Helpers
# ──────────────────────────────────────────────────────────────────────────────

def json_response(data, status=200):
    return JsonResponse(data, status=status, safe=isinstance(data, dict))


def get_user_watchlist_ids(user):
    if user.is_authenticated:
        return set(Watchlist.objects.filter(user=user).values_list('movie_id', flat=True))
    return set()


def enrich_movies(movies, user):
    """Add watchlist status to each movie dict."""
    wl_ids = get_user_watchlist_ids(user)
    result = []
    for m in movies:
        d = m.to_dict()
        d['in_watchlist'] = m.id in wl_ids
        result.append(d)
    return result


# ──────────────────────────────────────────────────────────────────────────────
# Page Views
# ──────────────────────────────────────────────────────────────────────────────

def homepage(request):
    featured = Movie.objects.filter(is_featured=True).first()
    return render(request, 'movix/index.html', {'featured': featured})


@login_required
def watchlist_page(request):
    return render(request, 'movix/watchlist.html')


# ──────────────────────────────────────────────────────────────────────────────
# Auth Views
# ──────────────────────────────────────────────────────────────────────────────

def register_page(request):
    if request.method == 'POST':
        try:
            data = json.loads(request.body)
        except Exception:
            data = request.POST

        username = data.get('username', '').strip()
        email    = data.get('email', '').strip()
        password = data.get('password', '')

        if not username or not password:
            return json_response({'error': 'Username and password are required.'}, 400)

        if User.objects.filter(username=username).exists():
            return json_response({'error': 'Username already taken.'}, 400)

        user = User.objects.create_user(username=username, email=email, password=password)
        UserProfile.objects.create(user=user)
        login(request, user)
        return json_response({'success': True, 'username': user.username})

    return render(request, 'movix/auth.html', {'mode': 'register'})


def login_page(request):
    if request.method == 'POST':
        try:
            data = json.loads(request.body)
        except Exception:
            data = request.POST

        username = data.get('username', '').strip()
        password = data.get('password', '')

        user = authenticate(request, username=username, password=password)
        if user:
            login(request, user)
            return json_response({'success': True, 'username': user.username})
        return json_response({'error': 'Invalid credentials.'}, 401)

    return render(request, 'movix/auth.html', {'mode': 'login'})


def logout_view(request):
    logout(request)
    return redirect('/')


# ──────────────────────────────────────────────────────────────────────────────
# Movie API
# ──────────────────────────────────────────────────────────────────────────────

def api_movies(request):
    """
    GET /api/movies/
    Query params:
      q       - search term
      genre   - filter by genre slug
      filter  - 'trending' | 'featured' | 'top_rated'
      page    - page number (20 per page)
    """
    qs = Movie.objects.all()

    query  = request.GET.get('q', '').strip()
    genre  = request.GET.get('genre', '').strip()
    filt   = request.GET.get('filter', '').strip()
    page   = int(request.GET.get('page', 1))
    per_page = 20

    if query:
        qs = qs.filter(Q(title__icontains=query) | Q(description__icontains=query))

    if genre:
        qs = qs.filter(genre=genre)

    if filt == 'trending':
        qs = qs.filter(is_trending=True)
    elif filt == 'featured':
        qs = qs.filter(is_featured=True)
    elif filt == 'top_rated':
        qs = qs.order_by('-rating')

    total   = qs.count()
    start   = (page - 1) * per_page
    movies  = qs[start:start + per_page]

    return json_response({
        'count':    total,
        'page':     page,
        'pages':    (total + per_page - 1) // per_page,
        'movies':   enrich_movies(movies, request.user),
    })


def api_movie_detail(request, movie_id):
    """GET /api/movies/<id>/"""
    try:
        movie = Movie.objects.get(id=movie_id)
    except Movie.DoesNotExist:
        return json_response({'error': 'Movie not found.'}, 404)

    data = movie.to_dict()
    data['in_watchlist'] = movie.id in get_user_watchlist_ids(request.user)

    if request.user.is_authenticated:
        user_rating = UserRating.objects.filter(user=request.user, movie=movie).first()
        data['my_rating'] = user_rating.score if user_rating else None
    else:
        data['my_rating'] = None

    return json_response(data)


@csrf_exempt
def api_add_movie(request):
    """POST /api/movies/add/ — add a movie manually (demo purposes)."""
    if request.method != 'POST':
        return json_response({'error': 'POST required.'}, 405)

    try:
        data = json.loads(request.body)
    except Exception:
        return json_response({'error': 'Invalid JSON.'}, 400)

    required = ['title', 'genre', 'description']
    for field in required:
        if not data.get(field):
            return json_response({'error': f'Field "{field}" is required.'}, 400)

    movie = Movie.objects.create(
        title        = data['title'],
        description  = data['description'],
        genre        = data['genre'],
        release_year = int(data.get('release_year', 2024)),
        duration_min = int(data.get('duration_min', 120)),
        director     = data.get('director', ''),
        cast_list    = data.get('cast_list', ''),
        poster_url   = data.get('poster_url', ''),
        backdrop_url = data.get('backdrop_url', ''),
        rating       = float(data.get('rating', 0.0)),
        vote_count   = int(data.get('vote_count', 0)),
        is_featured  = bool(data.get('is_featured', False)),
        is_trending  = bool(data.get('is_trending', False)),
    )
    return json_response({'success': True, 'movie': movie.to_dict()}, 201)


@csrf_exempt
def api_delete_movie(request, movie_id):
    """POST /api/movies/delete/<id>/"""
    if request.method != 'POST':
        return json_response({'error': 'POST required.'}, 405)

    try:
        movie = Movie.objects.get(id=movie_id)
    except Movie.DoesNotExist:
        return json_response({'error': 'Movie not found.'}, 404)

    movie.delete()
    return json_response({'success': True})


# ──────────────────────────────────────────────────────────────────────────────
# Watchlist API
# ──────────────────────────────────────────────────────────────────────────────

@login_required
def api_watchlist(request):
    """GET /api/watchlist/ — return the current user's watchlist."""
    items = Watchlist.objects.filter(user=request.user).select_related('movie')
    result = []
    for item in items:
        d = item.movie.to_dict()
        d['in_watchlist']  = True
        d['is_watched']    = item.is_watched
        d['watchlist_id']  = item.id
        d['added_at']      = item.added_at.isoformat()
        result.append(d)
    return json_response({'watchlist': result, 'count': len(result)})


@csrf_exempt
@login_required
def api_watchlist_toggle(request):
    """
    POST /api/watchlist/toggle/
    Body: { "movie_id": <int> }
    Adds the movie if not in watchlist; removes it if already there.
    """
    if request.method != 'POST':
        return json_response({'error': 'POST required.'}, 405)

    try:
        data     = json.loads(request.body)
        movie_id = int(data['movie_id'])
    except (KeyError, ValueError, json.JSONDecodeError):
        return json_response({'error': 'movie_id required.'}, 400)

    try:
        movie = Movie.objects.get(id=movie_id)
    except Movie.DoesNotExist:
        return json_response({'error': 'Movie not found.'}, 404)

    entry, created = Watchlist.objects.get_or_create(user=request.user, movie=movie)
    if not created:
        entry.delete()
        return json_response({'action': 'removed', 'in_watchlist': False})

    watchlist_count = Watchlist.objects.filter(user=request.user).count()
    return json_response({'action': 'added', 'in_watchlist': True, 'count': watchlist_count})


@csrf_exempt
@login_required
def api_mark_watched(request):
    """POST /api/watchlist/watched/ — toggle watched state."""
    if request.method != 'POST':
        return json_response({'error': 'POST required.'}, 405)

    try:
        data     = json.loads(request.body)
        movie_id = int(data['movie_id'])
    except Exception:
        return json_response({'error': 'movie_id required.'}, 400)

    try:
        entry = Watchlist.objects.get(user=request.user, movie_id=movie_id)
    except Watchlist.DoesNotExist:
        return json_response({'error': 'Not in watchlist.'}, 404)

    entry.is_watched = not entry.is_watched
    entry.save()
    return json_response({'is_watched': entry.is_watched})


# ──────────────────────────────────────────────────────────────────────────────
# Rating API
# ──────────────────────────────────────────────────────────────────────────────

@csrf_exempt
@login_required
def api_rate_movie(request):
    """POST /api/rate/ — body: { "movie_id": int, "score": 1–5 }"""
    if request.method != 'POST':
        return json_response({'error': 'POST required.'}, 405)

    try:
        data     = json.loads(request.body)
        movie_id = int(data['movie_id'])
        score    = int(data['score'])
    except Exception:
        return json_response({'error': 'movie_id and score (1–5) required.'}, 400)

    if not 1 <= score <= 5:
        return json_response({'error': 'Score must be between 1 and 5.'}, 400)

    try:
        movie = Movie.objects.get(id=movie_id)
    except Movie.DoesNotExist:
        return json_response({'error': 'Movie not found.'}, 404)

    rating, _ = UserRating.objects.update_or_create(
        user=request.user, movie=movie,
        defaults={'score': score}
    )

    avg = UserRating.objects.filter(movie=movie).aggregate(Avg('score'))['score__avg']
    return json_response({'success': True, 'my_rating': score, 'avg_user_rating': round(avg, 2)})


# ──────────────────────────────────────────────────────────────────────────────
# Recommendation Engine
# ──────────────────────────────────────────────────────────────────────────────

def api_recommend(request):
    """
    GET /api/recommend/
    Rule-based: uses the logged-in user's watchlist genres + ratings.
    Falls back to top-rated movies for guests.
    """
    if not request.user.is_authenticated:
        movies = Movie.objects.order_by('-rating')[:12]
        return json_response({'movies': enrich_movies(movies, request.user), 'basis': 'top_rated'})

    # Gather genres the user seems to enjoy (watched or highly rated)
    watched_ids = Watchlist.objects.filter(
        user=request.user, is_watched=True
    ).values_list('movie_id', flat=True)

    top_rated_ids = UserRating.objects.filter(
        user=request.user, score__gte=4
    ).values_list('movie_id', flat=True)

    liked_ids = set(watched_ids) | set(top_rated_ids)

    if liked_ids:
        liked_genres = Movie.objects.filter(id__in=liked_ids).values_list('genre', flat=True)
        genre_freq   = {}
        for g in liked_genres:
            genre_freq[g] = genre_freq.get(g, 0) + 1

        preferred_genres = sorted(genre_freq, key=genre_freq.get, reverse=True)[:3]

        movies = Movie.objects.filter(
            genre__in=preferred_genres
        ).exclude(id__in=liked_ids).order_by('-rating')[:12]

        if movies.count() < 6:
            extra = Movie.objects.exclude(id__in=liked_ids).order_by('-rating')[:12 - movies.count()]
            movie_list = list(movies) + list(extra)
        else:
            movie_list = list(movies)

        return json_response({
            'movies': enrich_movies(movie_list, request.user),
            'basis':  f'Based on your taste in {", ".join(preferred_genres)}',
        })

    # New user — show top rated
    movies = Movie.objects.order_by('-rating')[:12]
    return json_response({'movies': enrich_movies(movies, request.user), 'basis': 'top_rated'})


# ──────────────────────────────────────────────────────────────────────────────
# TMDB Integration
# ──────────────────────────────────────────────────────────────────────────────

TMDB_BASE = 'https://api.themoviedb.org/3'
TMDB_IMG  = 'https://image.tmdb.org/t/p/w500'
TMDB_IMG_BACKDROP = 'https://image.tmdb.org/t/p/w1280'

TMDB_GENRE_MAP = {
    28: 'action', 35: 'comedy', 18: 'drama', 27: 'horror',
    878: 'sci-fi', 10749: 'romance', 53: 'thriller', 16: 'animation',
    99: 'documentary', 14: 'fantasy', 9648: 'mystery', 12: 'adventure',
}


def _tmdb_get(path, params=None):
    """Helper — make a GET request to the TMDB API."""
    api_key = settings.TMDB_API_KEY
    if api_key == 'YOUR_TMDB_API_KEY_HERE' or not api_key:
        return None, 'TMDB API key not configured.'

    params = params or {}
    params['api_key'] = api_key
    qs  = urllib.parse.urlencode(params)
    url = f"{TMDB_BASE}{path}?{qs}"

    try:
        with urllib.request.urlopen(url, timeout=10) as resp:
            return json.loads(resp.read()), None
    except Exception as e:
        return None, str(e)


def api_tmdb_search(request):
    """GET /api/tmdb/search/?q=<term>"""
    query = request.GET.get('q', '').strip()
    if not query:
        return json_response({'error': 'Query parameter "q" required.'}, 400)

    data, err = _tmdb_get('/search/movie', {'query': query, 'language': 'en-US', 'page': 1})
    if err:
        return json_response({'error': err}, 502)

    results = []
    for item in data.get('results', [])[:10]:
        genre_ids = item.get('genre_ids', [])
        genre = TMDB_GENRE_MAP.get(genre_ids[0], 'action') if genre_ids else 'action'
        results.append({
            'tmdb_id':      item['id'],
            'title':        item.get('title', ''),
            'description':  item.get('overview', ''),
            'poster_url':   TMDB_IMG + item['poster_path'] if item.get('poster_path') else '',
            'backdrop_url': TMDB_IMG_BACKDROP + item['backdrop_path'] if item.get('backdrop_path') else '',
            'rating':       item.get('vote_average', 0),
            'vote_count':   item.get('vote_count', 0),
            'release_year': int(item.get('release_date', '2000')[:4]) if item.get('release_date') else 2000,
            'genre':        genre,
        })

    return json_response({'results': results})


def api_tmdb_import(request, tmdb_id):
    """GET /api/tmdb/import/<tmdb_id>/ — fetch from TMDB and save to our DB."""
    if Movie.objects.filter(tmdb_id=tmdb_id).exists():
        movie = Movie.objects.get(tmdb_id=tmdb_id)
        return json_response({'movie': movie.to_dict(), 'imported': False, 'message': 'Already in database.'})

    data, err = _tmdb_get(f'/movie/{tmdb_id}', {'language': 'en-US', 'append_to_response': 'credits,videos'})
    if err:
        return json_response({'error': err}, 502)

    # Map TMDB genre IDs to our genre slugs
    genres     = data.get('genres', [])
    genre_slug = TMDB_GENRE_MAP.get(genres[0]['id'], 'action') if genres else 'action'

    # Director + cast from credits
    crew      = data.get('credits', {}).get('crew', [])
    cast_data = data.get('credits', {}).get('cast', [])
    directors = [p['name'] for p in crew if p.get('job') == 'Director']
    cast      = [p['name'] for p in cast_data[:6]]

    # Trailer
    videos   = data.get('videos', {}).get('results', [])
    trailer  = next((v for v in videos if v.get('type') == 'Trailer' and v.get('site') == 'YouTube'), None)
    trailer_url = f"https://www.youtube.com/watch?v={trailer['key']}" if trailer else ''

    movie = Movie.objects.create(
        tmdb_id      = tmdb_id,
        title        = data.get('title', ''),
        description  = data.get('overview', ''),
        genre        = genre_slug,
        release_year = int(data.get('release_date', '2000')[:4]) if data.get('release_date') else 2000,
        duration_min = data.get('runtime', 120) or 120,
        director     = directors[0] if directors else '',
        cast_list    = ', '.join(cast),
        poster_url   = TMDB_IMG + data['poster_path'] if data.get('poster_path') else '',
        backdrop_url = TMDB_IMG_BACKDROP + data['backdrop_path'] if data.get('backdrop_path') else '',
        trailer_url  = trailer_url,
        rating       = data.get('vote_average', 0),
        vote_count   = data.get('vote_count', 0),
    )
    return json_response({'movie': movie.to_dict(), 'imported': True}, 201)


# ──────────────────────────────────────────────────────────────────────────────
# AI Suggest: "Movies like X"
# ──────────────────────────────────────────────────────────────────────────────

@csrf_exempt
def api_ai_suggest(request):
    """
    POST /api/ai/suggest/
    Body: { "movie_id": <int>, "use_ai": true/false }

    1. Tries OpenAI if key is configured.
    2. Falls back to rule-based (same genre, similar rating, exclude original).
    """
    if request.method != 'POST':
        return json_response({'error': 'POST required.'}, 405)

    try:
        data     = json.loads(request.body)
        movie_id = int(data.get('movie_id', 0))
    except Exception:
        return json_response({'error': 'movie_id required.'}, 400)

    try:
        movie = Movie.objects.get(id=movie_id)
    except Movie.DoesNotExist:
        return json_response({'error': 'Movie not found.'}, 404)

    # ── Try OpenAI ──────────────────────────────────────────────────────────
    ai_explanation = None
    if settings.OPENAI_API_KEY:
        ai_explanation = _get_openai_suggestions(movie)

    # ── Rule-based fallback (always run to get actual DB movies) ───────────
    similar = Movie.objects.filter(
        genre=movie.genre
    ).exclude(id=movie.id).order_by('-rating')[:8]

    # Supplement with slightly different genres if not enough
    if similar.count() < 4:
        broader = Movie.objects.exclude(id=movie.id).order_by('-rating')[:8]
        movie_list = list(similar) + [m for m in broader if m not in similar]
    else:
        movie_list = list(similar)

    explanation = ai_explanation or (
        f"Because you're interested in '{movie.title}', we picked "
        f"movies with a similar {movie.genre} vibe and high ratings."
    )

    return json_response({
        'based_on':    movie.to_dict(),
        'suggestions': enrich_movies(movie_list[:6], request.user),
        'explanation': explanation,
    })


def _get_openai_suggestions(movie):
    """
    Ask OpenAI for a one-sentence explanation of why certain genres/themes
    are similar to the given movie. Returns a string or None on failure.
    """
    try:
        import urllib.request as ur
        payload = json.dumps({
            'model': 'gpt-3.5-turbo',
            'max_tokens': 120,
            'messages': [
                {
                    'role': 'system',
                    'content': (
                        'You are a concise movie recommendation assistant. '
                        'Reply in ONE sentence only.'
                    ),
                },
                {
                    'role': 'user',
                    'content': (
                        f'Why would a fan of "{movie.title}" ({movie.genre}, '
                        f'rated {movie.rating}/10) enjoy other {movie.genre} movies?'
                    ),
                },
            ],
        }).encode()

        req = ur.Request(
            'https://api.openai.com/v1/chat/completions',
            data=payload,
            headers={
                'Content-Type': 'application/json',
                'Authorization': f'Bearer {settings.OPENAI_API_KEY}',
            },
        )
        with ur.urlopen(req, timeout=8) as resp:
            result = json.loads(resp.read())
            return result['choices'][0]['message']['content'].strip()
    except Exception:
        return None


# ──────────────────────────────────────────────────────────────────────────────
# Auth Status (for JS to check session)
# ──────────────────────────────────────────────────────────────────────────────

def api_auth_status(request):
    if request.user.is_authenticated:
        wl_count = Watchlist.objects.filter(user=request.user).count()
        return json_response({
            'authenticated': True,
            'username':      request.user.username,
            'watchlist_count': wl_count,
        })
    return json_response({'authenticated': False, 'watchlist_count': 0})
