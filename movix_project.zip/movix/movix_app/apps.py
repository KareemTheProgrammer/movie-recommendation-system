from django.apps import AppConfig


class MovixAppConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'movix_app'
    verbose_name = 'MOVIX'
