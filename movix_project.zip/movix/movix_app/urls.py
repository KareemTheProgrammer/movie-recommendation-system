"""
MOVIX — App URL Patterns
"""

from django.urls import path
from . import views

urlpatterns = [
    # ── Pages ─────────────────────────────────────────────────────────────────
    path('',                      views.homepage,         name='home'),
    path('watchlist/',            views.watchlist_page,   name='watchlist'),
    path('register/',             views.register_page,    name='register'),
    path('login/',                views.login_page,       name='login'),
    path('logout/',               views.logout_view,      name='logout'),

    # ── Movie API ─────────────────────────────────────────────────────────────
    path('api/movies/',           views.api_movies,       name='api_movies'),
    path('api/movies/<int:movie_id>/', views.api_movie_detail, name='api_movie_detail'),
    path('api/movies/add/',       views.api_add_movie,    name='api_add_movie'),
    path('api/movies/delete/<int:movie_id>/', views.api_delete_movie, name='api_delete_movie'),

    # ── Watchlist API ─────────────────────────────────────────────────────────
    path('api/watchlist/',        views.api_watchlist,         name='api_watchlist'),
    path('api/watchlist/toggle/', views.api_watchlist_toggle,  name='api_watchlist_toggle'),
    path('api/watchlist/watched/',views.api_mark_watched,      name='api_mark_watched'),

    # ── Rating API ────────────────────────────────────────────────────────────
    path('api/rate/',             views.api_rate_movie,   name='api_rate_movie'),

    # ── Recommendations ───────────────────────────────────────────────────────
    path('api/recommend/',        views.api_recommend,    name='api_recommend'),
    path('api/ai/suggest/',       views.api_ai_suggest,   name='api_ai_suggest'),

    # ── TMDB Proxy ────────────────────────────────────────────────────────────
    path('api/tmdb/search/',           views.api_tmdb_search,  name='api_tmdb_search'),
    path('api/tmdb/import/<int:tmdb_id>/', views.api_tmdb_import, name='api_tmdb_import'),

    # ── Auth Status ───────────────────────────────────────────────────────────
    path('api/auth/status/',      views.api_auth_status,  name='api_auth_status'),
]
